export default {
  transform: {
    "^.+\\.js$": "babel-jest",
  },
};
